from __future__ import annotations

from typing import Any

from flask import Flask, jsonify, request, url_for


VIDEOJUEGO_FIELDS = ("titulo", "url_caratula", "genero", "plataforma")


class MockVideojuegoRepository:
    """Repositorio en memoria para desarrollo y demostraciones."""

    def __init__(self) -> None:
        self._videojuegos: dict[int, dict[str, Any]] = {}
        self._next_id = 1

    def listar(self) -> list[dict[str, Any]]:
        return [videojuego.copy() for videojuego in self._videojuegos.values()]

    def obtener(self, videojuego_id: int) -> dict[str, Any] | None:
        videojuego = self._videojuegos.get(videojuego_id)
        return videojuego.copy() if videojuego is not None else None

    def crear(self, datos: dict[str, str]) -> dict[str, Any]:
        videojuego = {"id": self._next_id, **datos}
        self._videojuegos[self._next_id] = videojuego
        self._next_id += 1
        return videojuego.copy()

    def actualizar(
        self, videojuego_id: int, datos: dict[str, str]
    ) -> dict[str, Any] | None:
        videojuego = self._videojuegos.get(videojuego_id)
        if videojuego is None:
            return None
        videojuego.update(datos)
        return videojuego.copy()

    def eliminar(self, videojuego_id: int) -> bool:
        return self._videojuegos.pop(videojuego_id, None) is not None


def _validar_datos(
    payload: Any, parcial: bool = False
) -> tuple[dict[str, str] | None, str | None]:
    if not isinstance(payload, dict):
        return None, "El cuerpo debe ser un objeto JSON."

    desconocidos = set(payload) - set(VIDEOJUEGO_FIELDS)
    if desconocidos:
        return None, f"Campos no permitidos: {', '.join(sorted(desconocidos))}."

    if parcial and not payload:
        return None, "Debe proporcionar al menos un campo para actualizar."

    if not parcial:
        faltantes = set(VIDEOJUEGO_FIELDS) - set(payload)
        if faltantes:
            return None, f"Faltan campos obligatorios: {', '.join(sorted(faltantes))}."

    datos: dict[str, str] = {}
    for campo, valor in payload.items():
        if not isinstance(valor, str) or not valor.strip():
            return None, f"El campo '{campo}' debe ser un texto no vacío."
        datos[campo] = valor.strip()

    return datos, None


def create_app(repository: MockVideojuegoRepository | None = None) -> Flask:
    app = Flask(__name__)
    repositorio = repository or MockVideojuegoRepository()

    @app.get("/api/videojuegos")
    def listar_videojuegos():
        return jsonify(repositorio.listar())

    @app.post("/api/videojuegos")
    def crear_videojuego():
        datos, error = _validar_datos(request.get_json(silent=True))
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.crear(datos or {})
        respuesta = jsonify(videojuego)
        respuesta.status_code = 201
        respuesta.headers["Location"] = url_for(
            "obtener_videojuego", videojuego_id=videojuego["id"]
        )
        return respuesta

    @app.get("/api/videojuegos/<int:videojuego_id>")
    def obtener_videojuego(videojuego_id: int):
        videojuego = repositorio.obtener(videojuego_id)
        if videojuego is None:
            return jsonify(error="Videojuego no encontrado."), 404
        return jsonify(videojuego)

    @app.put("/api/videojuegos/<int:videojuego_id>")
    def reemplazar_videojuego(videojuego_id: int):
        if repositorio.obtener(videojuego_id) is None:
            return jsonify(error="Videojuego no encontrado."), 404

        datos, error = _validar_datos(request.get_json(silent=True))
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.actualizar(videojuego_id, datos or {})
        return jsonify(videojuego)

    @app.patch("/api/videojuegos/<int:videojuego_id>")
    def actualizar_videojuego(videojuego_id: int):
        if repositorio.obtener(videojuego_id) is None:
            return jsonify(error="Videojuego no encontrado."), 404

        datos, error = _validar_datos(
            request.get_json(silent=True), parcial=True
        )
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.actualizar(videojuego_id, datos or {})
        return jsonify(videojuego)

    @app.delete("/api/videojuegos/<int:videojuego_id>")
    def eliminar_videojuego(videojuego_id: int):
        if not repositorio.eliminar(videojuego_id):
            return jsonify(error="Videojuego no encontrado."), 404
        return "", 204

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)