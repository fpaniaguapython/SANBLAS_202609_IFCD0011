# API REST de videojuegos

API REST en Flask para gestionar videojuegos. La persistencia es un mock en memoria: los datos se reinician al detener el proceso.

## Instalación y ejecución

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

La API queda disponible en `http://127.0.0.1:5000`.

## Endpoints

| Método | Ruta | Descripción |
| --- | --- | --- |
| GET | `/api/videojuegos` | Lista todos los videojuegos |
| POST | `/api/videojuegos` | Crea un videojuego y asigna su ID |
| GET | `/api/videojuegos/{id}` | Obtiene un videojuego |
| PUT | `/api/videojuegos/{id}` | Reemplaza todos sus campos |
| PATCH | `/api/videojuegos/{id}` | Actualiza campos específicos |
| DELETE | `/api/videojuegos/{id}` | Elimina un videojuego |

Los campos editables son `titulo`, `url_caratula`, `genero` y `plataforma`. Todos deben ser textos no vacíos. El campo `id` es autoincremental y no se envía al crear.

Ejemplo de creación:

```json
{
  "titulo": "Portal 2",
  "url_caratula": "https://example.com/portal2.jpg",
  "genero": "Puzzle",
  "plataforma": "PC"
}
```

## Pruebas

```powershell
python -m unittest discover -v
```