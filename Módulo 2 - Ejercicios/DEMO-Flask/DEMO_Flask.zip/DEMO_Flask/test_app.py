import unittest

from app import create_app


class VideojuegosApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.client = create_app().test_client()
        self.videojuego = {
            "titulo": "Portal 2",
            "url_caratula": "https://example.com/portal2.jpg",
            "genero": "Puzzle",
            "plataforma": "PC",
        }

    def crear_videojuego(self) -> dict:
        respuesta = self.client.post("/api/videojuegos", json=self.videojuego)
        self.assertEqual(respuesta.status_code, 201)
        return respuesta.get_json()

    def test_crear_asigna_id_autoincremental_y_location(self) -> None:
        primero = self.crear_videojuego()
        segundo = self.crear_videojuego()

        self.assertEqual(primero["id"], 1)
        self.assertEqual(segundo["id"], 2)
        respuesta = self.client.post("/api/videojuegos", json=self.videojuego)
        self.assertEqual(respuesta.headers["Location"], "/api/videojuegos/3")

    def test_listar_obtener_actualizar_y_eliminar(self) -> None:
        creado = self.crear_videojuego()
        videojuego_id = creado["id"]

        lista = self.client.get("/api/videojuegos")
        self.assertEqual(lista.status_code, 200)
        self.assertEqual(len(lista.get_json()), 1)

        obtenido = self.client.get(f"/api/videojuegos/{videojuego_id}")
        self.assertEqual(obtenido.get_json(), creado)

        actualizado = self.client.patch(
            f"/api/videojuegos/{videojuego_id}", json={"plataforma": "Switch"}
        )
        self.assertEqual(actualizado.status_code, 200)
        self.assertEqual(actualizado.get_json()["plataforma"], "Switch")
        self.assertEqual(actualizado.get_json()["titulo"], "Portal 2")

        eliminado = self.client.delete(f"/api/videojuegos/{videojuego_id}")
        self.assertEqual(eliminado.status_code, 204)
        self.assertEqual(
            self.client.get(f"/api/videojuegos/{videojuego_id}").status_code, 404
        )

    def test_put_reemplaza_todos_los_campos(self) -> None:
        creado = self.crear_videojuego()
        reemplazo = {
            **self.videojuego,
            "titulo": "Portal",
            "genero": "Accion",
        }

        respuesta = self.client.put(
            f"/api/videojuegos/{creado['id']}", json=reemplazo
        )

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.get_json()["titulo"], "Portal")
        self.assertEqual(respuesta.get_json()["genero"], "Accion")

    def test_rechaza_datos_invalidos_y_ids_inexistentes(self) -> None:
        incompleto = self.client.post(
            "/api/videojuegos", json={"titulo": "Portal 2"}
        )
        self.assertEqual(incompleto.status_code, 400)

        vacio = self.client.post(
            "/api/videojuegos", json={**self.videojuego, "genero": " "}
        )
        self.assertEqual(vacio.status_code, 400)

        inexistente = self.client.get("/api/videojuegos/99")
        self.assertEqual(inexistente.status_code, 404)


if __name__ == "__main__":
    unittest.main()