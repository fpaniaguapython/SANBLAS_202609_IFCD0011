from dataclasses import dataclass


@dataclass(frozen=True)
class Videojuego:
    titulo: str
    url_caratula: str
    genero: str
    plataforma: str
    id: int | None = None

    def to_dict(self) -> dict[str, int | str | None]:
        return {
            "id": self.id,
            "titulo": self.titulo,
            "url_caratula": self.url_caratula,
            "genero": self.genero,
            "plataforma": self.plataforma,
        }
