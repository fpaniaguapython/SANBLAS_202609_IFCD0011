from .videojuego import Videojuego

__all__ = ["Videojuego"]
