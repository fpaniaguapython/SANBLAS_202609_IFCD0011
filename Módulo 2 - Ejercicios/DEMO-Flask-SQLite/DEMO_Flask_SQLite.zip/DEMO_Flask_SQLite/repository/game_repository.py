import sqlite3
from dataclasses import replace
from pathlib import Path
from threading import RLock

from entity import Videojuego


class GameRepository:
    _CAMPOS = ("titulo", "url_caratula", "genero", "plataforma")

    def __init__(self, database_path: str | Path = "videojuegos.db") -> None:
        self._database_path = str(database_path)
        if self._database_path != ":memory:":
            Path(self._database_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._connection = sqlite3.connect(
            self._database_path, check_same_thread=False
        )
        self._connection.row_factory = sqlite3.Row
        with self._lock, self._connection:
            self._connection.execute(
                """
                CREATE TABLE IF NOT EXISTS videojuegos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    titulo TEXT NOT NULL,
                    url_caratula TEXT NOT NULL,
                    genero TEXT NOT NULL,
                    plataforma TEXT NOT NULL
                )
                """
            )

    @staticmethod
    def _a_videojuego(fila: sqlite3.Row) -> Videojuego:
        return Videojuego(
            id=fila["id"],
            titulo=fila["titulo"],
            url_caratula=fila["url_caratula"],
            genero=fila["genero"],
            plataforma=fila["plataforma"],
        )

    @staticmethod
    def _patron_busqueda(termino: str) -> str:
        escapado = (
            termino.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        )
        return f"%{escapado}%"

    def listar(
        self,
        titulo: str | None = None,
        genero: str | None = None,
        plataforma: str | None = None,
    ) -> list[Videojuego]:
        filtros = {
            "titulo": titulo,
            "genero": genero,
            "plataforma": plataforma,
        }
        condiciones: list[str] = []
        valores: list[str] = []
        for campo, termino in filtros.items():
            if termino:
                condiciones.append(f"{campo} LIKE ? ESCAPE '\\'")
                valores.append(self._patron_busqueda(termino))

        consulta = "SELECT * FROM videojuegos"
        if condiciones:
            consulta += " WHERE " + " AND ".join(condiciones)
        consulta += " ORDER BY id"

        with self._lock, self._connection:
            filas = self._connection.execute(consulta, valores).fetchall()
        return [self._a_videojuego(fila) for fila in filas]

    def obtener(self, videojuego_id: int) -> Videojuego | None:
        with self._lock, self._connection:
            fila = self._connection.execute(
                "SELECT * FROM videojuegos WHERE id = ?", (videojuego_id,)
            ).fetchone()
        return self._a_videojuego(fila) if fila is not None else None

    def crear(self, videojuego: Videojuego) -> Videojuego:
        with self._lock, self._connection:
            cursor = self._connection.execute(
                """
                INSERT INTO videojuegos (titulo, url_caratula, genero, plataforma)
                VALUES (?, ?, ?, ?)
                """,
                (
                    videojuego.titulo,
                    videojuego.url_caratula,
                    videojuego.genero,
                    videojuego.plataforma,
                ),
            )
            videojuego_id = cursor.lastrowid
        if videojuego_id is None:
            raise RuntimeError("SQLite no devolvió el ID del videojuego creado.")
        return replace(videojuego, id=videojuego_id)

    def actualizar(
        self, videojuego_id: int, datos: dict[str, str]
    ) -> Videojuego | None:
        campos = tuple(campo for campo in self._CAMPOS if campo in datos)
        desconocidos = set(datos) - set(self._CAMPOS)
        if desconocidos:
            raise ValueError(f"Campos no permitidos: {', '.join(sorted(desconocidos))}.")
        if not campos:
            return self.obtener(videojuego_id)

        asignaciones = ", ".join(f"{campo} = ?" for campo in campos)
        valores = [datos[campo] for campo in campos]
        valores.append(videojuego_id)
        with self._lock, self._connection:
            cursor = self._connection.execute(
                f"UPDATE videojuegos SET {asignaciones} WHERE id = ?", valores
            )
            if cursor.rowcount == 0:
                return None
            fila = self._connection.execute(
                "SELECT * FROM videojuegos WHERE id = ?", (videojuego_id,)
            ).fetchone()
        return self._a_videojuego(fila) if fila is not None else None

    def eliminar(self, videojuego_id: int) -> bool:
        with self._lock, self._connection:
            cursor = self._connection.execute(
                "DELETE FROM videojuegos WHERE id = ?", (videojuego_id,)
            )
        return cursor.rowcount > 0

    def buscar_por_titulo(self, titulo: str) -> list[Videojuego]:
        return self.listar(titulo=titulo)

    def buscar_por_genero(self, genero: str) -> list[Videojuego]:
        return self.listar(genero=genero)

    def buscar_por_plataforma(self, plataforma: str) -> list[Videojuego]:
        return self.listar(plataforma=plataforma)

    def cerrar(self) -> None:
        with self._lock:
            self._connection.close()
