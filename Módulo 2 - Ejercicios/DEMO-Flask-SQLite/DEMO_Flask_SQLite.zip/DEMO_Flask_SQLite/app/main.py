from __future__ import annotations

import os
from typing import Any

from flask import Flask, jsonify, request, url_for

from entity import Videojuego
from repository import GameRepository

VIDEOJUEGO_FIELDS = ("titulo", "url_caratula", "genero", "plataforma")


def _validar_datos(
    payload: Any, parcial: bool = False
) -> tuple[dict[str, str] | None, str | None]:
    if not isinstance(payload, dict):
        return None, "El cuerpo debe ser un objeto JSON."

    desconocidos = set(payload) - set(VIDEOJUEGO_FIELDS)
    if desconocidos:
        return None, f"Campos no permitidos: {', '.join(sorted(desconocidos))}."

    if parcial and not payload:
        return None, "Debe proporcionar al menos un campo para actualizar."

    if not parcial:
        faltantes = set(VIDEOJUEGO_FIELDS) - set(payload)
        if faltantes:
            return None, f"Faltan campos obligatorios: {', '.join(sorted(faltantes))}."

    datos: dict[str, str] = {}
    for campo, valor in payload.items():
        if not isinstance(valor, str) or not valor.strip():
            return None, f"El campo '{campo}' debe ser un texto no vacío."
        datos[campo] = valor.strip()

    return datos, None


def create_app(
    repository: GameRepository | None = None,
    database_path: str | None = None,
) -> Flask:
    app = Flask(__name__)
    repositorio = repository or GameRepository(database_path or ":memory:")

    @app.get("/api/videojuegos")
    def listar_videojuegos():
        videojuegos = repositorio.listar(
            titulo=request.args.get("titulo"),
            genero=request.args.get("genero"),
            plataforma=request.args.get("plataforma"),
        )
        return jsonify([videojuego.to_dict() for videojuego in videojuegos])

    @app.post("/api/videojuegos")
    def crear_videojuego():
        datos, error = _validar_datos(request.get_json(silent=True))
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.crear(Videojuego(**(datos or {})))
        respuesta = jsonify(videojuego.to_dict())
        respuesta.status_code = 201
        respuesta.headers["Location"] = url_for(
            "obtener_videojuego", videojuego_id=videojuego.id
        )
        return respuesta

    @app.get("/api/videojuegos/<int:videojuego_id>")
    def obtener_videojuego(videojuego_id: int):
        videojuego = repositorio.obtener(videojuego_id)
        if videojuego is None:
            return jsonify(error="Videojuego no encontrado."), 404
        return jsonify(videojuego.to_dict())

    @app.put("/api/videojuegos/<int:videojuego_id>")
    def reemplazar_videojuego(videojuego_id: int):
        if repositorio.obtener(videojuego_id) is None:
            return jsonify(error="Videojuego no encontrado."), 404

        datos, error = _validar_datos(request.get_json(silent=True))
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.actualizar(videojuego_id, datos or {})
        if videojuego is None:
            return jsonify(error="Videojuego no encontrado."), 404
        return jsonify(videojuego.to_dict())

    @app.patch("/api/videojuegos/<int:videojuego_id>")
    def actualizar_videojuego(videojuego_id: int):
        if repositorio.obtener(videojuego_id) is None:
            return jsonify(error="Videojuego no encontrado."), 404

        datos, error = _validar_datos(
            request.get_json(silent=True), parcial=True
        )
        if error:
            return jsonify(error=error), 400

        videojuego = repositorio.actualizar(videojuego_id, datos or {})
        if videojuego is None:
            return jsonify(error="Videojuego no encontrado."), 404
        return jsonify(videojuego.to_dict())

    @app.delete("/api/videojuegos/<int:videojuego_id>")
    def eliminar_videojuego(videojuego_id: int):
        if not repositorio.eliminar(videojuego_id):
            return jsonify(error="Videojuego no encontrado."), 404
        return "", 204

    return app


app = create_app(
    database_path=os.environ.get("VIDEOJUEGOS_DATABASE", "videojuegos.db")
)


if __name__ == "__main__":
    app.run(debug=True)