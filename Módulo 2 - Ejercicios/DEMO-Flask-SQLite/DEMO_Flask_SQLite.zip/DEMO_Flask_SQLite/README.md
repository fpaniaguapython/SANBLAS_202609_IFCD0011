# API REST de videojuegos

API REST desarrollada con Flask para gestionar videojuegos. Guarda los datos en
SQLite mediante `GameRepository`.

## Requisitos

- Python 3.10 o posterior
- pip

## Instalación y ejecución

Desde la carpeta raíz del proyecto, ejecuta en PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m app.main
```

La API estará disponible en `http://127.0.0.1:5000`.

Al ejecutar el servidor, la base de datos se crea como `videojuegos.db` en la
carpeta actual. Se puede seleccionar otra ruta configurando la variable de
entorno `VIDEOJUEGOS_DATABASE` antes de iniciar la aplicación. La función
`create_app()` usa SQLite en memoria por defecto.

## Endpoints

| Método | Ruta | Descripción |
| --- | --- | --- |
| GET | `/api/videojuegos` | Lista todos los videojuegos; admite filtros |
| POST | `/api/videojuegos` | Crea un videojuego |
| GET | `/api/videojuegos/{id}` | Obtiene un videojuego por ID |
| PUT | `/api/videojuegos/{id}` | Reemplaza todos sus campos |
| PATCH | `/api/videojuegos/{id}` | Actualiza uno o varios campos |
| DELETE | `/api/videojuegos/{id}` | Elimina un videojuego |

Los filtros del listado son `titulo`, `genero` y `plataforma`. La búsqueda es
parcial y no distingue mayúsculas de minúsculas. Es posible combinar filtros:

```text
GET /api/videojuegos?genero=puzzle&plataforma=pc
```

Los campos aceptados para crear y actualizar son `titulo`, `url_caratula`,
`genero` y `plataforma`. Deben ser textos no vacíos; al actualizar con `PATCH`
se puede enviar solo el campo o los campos que se desean modificar. El `id` se
genera automáticamente.

Ejemplo de creación:

```json
{
  "titulo": "Portal 2",
  "url_caratula": "https://example.com/portal2.jpg",
  "genero": "Puzzle",
  "plataforma": "PC"
}
```

## Estructura principal

- `app/main.py`: aplicación Flask y rutas de la API.
- `entity/videojuego.py`: entidad `Videojuego`.
- `repository/game_repository.py`: acceso SQLite, operaciones CRUD y búsquedas.

