# SQLAlchemyDEMO
Demostración básica de SQLAlchemy sobre SQLite
