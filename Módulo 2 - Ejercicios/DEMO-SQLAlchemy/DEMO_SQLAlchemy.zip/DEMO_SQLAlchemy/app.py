import db.dbalchemy_manager as db

def inicializar_db() -> None:
    for videojuego in db.listar_videojuegos():
        db.eliminar_videojuego(videojuego.id)

    videojuegos_iniciales = [
        db.VideojuegoDatos("The Legend of Zelda: Breath of the Wild", "Aventura", "Nintendo Switch", 2017, 59.99),
        db.VideojuegoDatos("Super Mario Odyssey", "Plataformas", "Nintendo Switch", 2017, 59.99),
        db.VideojuegoDatos("Mario Kart 8 Deluxe", "Carreras", "Nintendo Switch", 2017, 59.99),
        db.VideojuegoDatos("God of War", "Accion", "PlayStation 4", 2018, 39.99),
        db.VideojuegoDatos("The Last of Us Part II", "Aventura", "PlayStation 4", 2020, 49.99),
        db.VideojuegoDatos("Halo Infinite", "Accion", "Xbox Series X", 2021, 59.99),
        db.VideojuegoDatos("Forza Horizon 5", "Carreras", "Xbox Series X", 2021, 59.99),
        db.VideojuegoDatos("Minecraft", "Sandbox", "PC", 2011, 29.99),
        db.VideojuegoDatos("Stardew Valley", "Simulacion", "PC", 2016, 14.99),
        db.VideojuegoDatos("Baldur's Gate 3", "Rol", "PC", 2023, 59.99),
    ]

    for datos in videojuegos_iniciales:
        db.crear_videojuego(datos)


def mostrar_datos() -> None:
    for videojuego in db.listar_videojuegos():
        print(
            videojuego.id,
            videojuego.nombre,
            videojuego.genero,
            videojuego.plataforma,
            videojuego.fecha_lanzamiento,
            videojuego.precio,
        )


if __name__ == "__main__":
    if not db.listar_videojuegos():
        inicializar_db()
    mostrar_datos()