from dataclasses import dataclass

from sqlalchemy import create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column


class Base(DeclarativeBase):
    # Esta clase es la base para todos los modelos
    # Podría agregar métodos y atributos comunes a todos los modelos.
    # Normalmente se deja vacía.
    pass

class Videojuego(Base):
    __tablename__ = "videojuegos"

    id: Mapped[int] = mapped_column(primary_key=True)
    nombre: Mapped[str]
    genero: Mapped[str]
    plataforma: Mapped[str]
    fecha_lanzamiento: Mapped[int]
    precio: Mapped[float]


@dataclass
class VideojuegoDatos:
    nombre: str
    genero: str
    plataforma: str
    fecha_lanzamiento: int
    precio: float


engine = create_engine("sqlite:///videojuegos.db")

Base.metadata.create_all(engine)


def crear_videojuego(datos: VideojuegoDatos) -> Videojuego:
    with Session(engine) as session:
        videojuego = Videojuego(
            nombre=datos.nombre,
            genero=datos.genero,
            plataforma=datos.plataforma,
            fecha_lanzamiento=datos.fecha_lanzamiento,
            precio=datos.precio,
        )
        session.add(videojuego)
        session.commit()
        session.refresh(videojuego)
        return videojuego


def listar_videojuegos() -> list[Videojuego]:
    with Session(engine) as session:
        return session.scalars(select(Videojuego)).all()


def buscar_videojuegos_por_genero(genero: str) -> list[Videojuego]:
    with Session(engine) as session:
        consulta = select(Videojuego).where(Videojuego.genero == genero)
        return session.scalars(consulta).all()


def buscar_videojuegos_por_plataforma(plataforma: str) -> list[Videojuego]:
    with Session(engine) as session:
        consulta = select(Videojuego).where(Videojuego.plataforma == plataforma)
        return session.scalars(consulta).all()


def obtener_videojuego(videojuego_id: int) -> Videojuego | None:
    with Session(engine) as session:
        return session.get(Videojuego, videojuego_id)


def actualizar_videojuego(
    videojuego_id: int, datos: VideojuegoDatos
) -> Videojuego | None:
    with Session(engine) as session:
        videojuego = session.get(Videojuego, videojuego_id)
        if videojuego is None:
            return None

        videojuego.nombre = datos.nombre
        videojuego.genero = datos.genero
        videojuego.plataforma = datos.plataforma
        videojuego.fecha_lanzamiento = datos.fecha_lanzamiento
        videojuego.precio = datos.precio
        session.commit()
        session.refresh(videojuego)
        return videojuego


def eliminar_videojuego(videojuego_id: int) -> bool:
    with Session(engine) as session:
        videojuego = session.get(Videojuego, videojuego_id)
        if videojuego is None:
            return False

        session.delete(videojuego)
        session.commit()
        return True